package com.API.APItop;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.API.APItop.Controller.ProfessorController;
import com.API.APItop.Model.Professor;
import com.API.APItop.Service.ProfessorService;

@WebMvcTest(ProfessorController.class)
class ApItopApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockitoBean
	private ProfessorService professorService;

	@Test
	void deveListarProfessores() throws Exception {
		when(professorService.listarTodos()).thenReturn(List.of(professor(1L, "João da Silva")));

		mockMvc.perform(get("/professores"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].nome").value("João da Silva"));
	}

	@Test
	void deveFiltrarProfessoresPorNome() throws Exception {
		when(professorService.buscarPorNome("joao")).thenReturn(List.of(professor(1L, "João da Silva")));

		mockMvc.perform(get("/professores/nome/joao"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].id").value(1));
	}

	@Test
	void deveFiltrarProfessoresPorArea() throws Exception {
		when(professorService.buscarPorArea("desenvolvimento"))
				.thenReturn(List.of(professor(1L, "João da Silva")));

		mockMvc.perform(get("/professores/area/desenvolvimento"))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$[0].area").value("Desenvolvimento"));
	}

	@Test
	void deveCadastrarProfessor() throws Exception {
		when(professorService.cadastrar(any(Professor.class))).thenReturn(professor(2L, "Maria Silva"));

		mockMvc.perform(post("/professores")
					.contentType("application/json")
					.content("""
							{"nome":"Maria Silva","email":"maria@email.com","area":"Desenvolvimento","telefone":"86999999999"}
							"""))
				.andExpect(status().isCreated())
				.andExpect(jsonPath("$.id").value(2))
				.andExpect(jsonPath("$.nome").value("Maria Silva"));
	}

	@Test
	void deveAtualizarProfessor() throws Exception {
		when(professorService.atualizar(eq(1L), any(Professor.class)))
				.thenReturn(professor(1L, "Maria Silva Santos"));

		mockMvc.perform(put("/professores/1")
					.contentType("application/json")
					.content("""
							{"nome":"Maria Silva Santos","email":"mariasantos@email.com","area":"Engenharia de Software","telefone":"86988888888"}
							"""))
				.andExpect(status().isOk())
				.andExpect(jsonPath("$.nome").value("Maria Silva Santos"));
	}

	@Test
	void deveExcluirProfessor() throws Exception {
		mockMvc.perform(delete("/professores/1"))
				.andExpect(status().isNoContent());

		verify(professorService).excluir(1L);
	}

	private Professor professor(Long id, String nome) {
		return new Professor(id, nome, "professor@example.com", "Desenvolvimento", "86999990000");
	}
}
