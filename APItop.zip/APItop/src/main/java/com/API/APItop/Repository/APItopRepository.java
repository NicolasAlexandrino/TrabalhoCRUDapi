package com.API.APItop.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.API.APItop.Model.Professor;

public interface ProfessorRepository extends JpaRepository<Professor, Long> {
	List<Professor> findByNomeContainingIgnoreCase(String nome);

	List<Professor> findByAreaIgnoreCase(String area);
}
