package com.API.APItop.Service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.API.APItop.Model.Professor;
import com.API.APItop.Repository.ProfessorRepository;

@Service
@Transactional
public class ProfessorService {

	private final ProfessorRepository professorRepository;

	public ProfessorService(ProfessorRepository professorRepository) {
		this.professorRepository = professorRepository;
	}

	@Transactional(readOnly = true)
	public List<Professor> listarTodos() {
		return professorRepository.findAll();
	}

	@Transactional(readOnly = true)
	public List<Professor> buscarPorNome(String nome) {
		return professorRepository.findByNomeContainingIgnoreCase(nome);
	}

	@Transactional(readOnly = true)
	public List<Professor> buscarPorArea(String area) {
		return professorRepository.findByAreaIgnoreCase(area);
	}

	public Professor cadastrar(Professor professor) {
		professor.setId(null);
		return professorRepository.save(professor);
	}

	public Professor atualizar(Long id, Professor dados) {
		Professor professor = professorRepository.findById(id)
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Professor não encontrado"));
		professor.setNome(dados.getNome());
		professor.setEmail(dados.getEmail());
		professor.setArea(dados.getArea());
		professor.setTelefone(dados.getTelefone());
		return professorRepository.save(professor);
	}

	public void excluir(Long id) {
		if (!professorRepository.existsById(id)) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Professor não encontrado");
		}
		professorRepository.deleteById(id);
	}
}