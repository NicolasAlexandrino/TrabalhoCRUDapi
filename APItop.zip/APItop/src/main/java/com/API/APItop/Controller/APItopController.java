package com.API.APItop.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.API.APItop.Model.Professor;
import com.API.APItop.Service.ProfessorService;

@RestController
@RequestMapping("/professores")
public class ProfessorController {

	private final ProfessorService professorService;

	public ProfessorController(ProfessorService professorService) {
		this.professorService = professorService;
	}

	@GetMapping
	public List<Professor> listarTodos() {
		return professorService.listarTodos();
	}

	@GetMapping("/nome/{nome}")
	public List<Professor> buscarPorNome(@PathVariable String nome) {
		return professorService.buscarPorNome(nome);
	}

	@GetMapping("/area/{area}")
	public List<Professor> buscarPorArea(@PathVariable String area) {
		return professorService.buscarPorArea(area);
	}

	@PostMapping
	public ResponseEntity<Professor> cadastrar(@RequestBody Professor professor) {
		return ResponseEntity.status(HttpStatus.CREATED).body(professorService.cadastrar(professor));
	}

	@PutMapping("/{id}")
	public Professor atualizar(@PathVariable Long id, @RequestBody Professor professor) {
		return professorService.atualizar(id, professor);
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> excluir(@PathVariable Long id) {
		professorService.excluir(id);
		return ResponseEntity.noContent().build();
	}
}
