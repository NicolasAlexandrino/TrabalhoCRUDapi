package com.API.APItop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApItopApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApItopApplication.class, args);
	}

}
