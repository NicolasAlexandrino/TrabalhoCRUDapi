INSERT INTO professor (nome, email, area, telefone)
SELECT 'João da Silva', 'joao.silva@example.com', 'Desenvolvimento', '86999990001'
WHERE NOT EXISTS (
    SELECT 1 FROM professor WHERE email = 'joao.silva@example.com'
);

INSERT INTO professor (nome, email, area, telefone)
SELECT 'Maria Joana', 'maria.joana@example.com', 'Engenharia de Software', '86999990002'
WHERE NOT EXISTS (
    SELECT 1 FROM professor WHERE email = 'maria.joana@example.com'
);